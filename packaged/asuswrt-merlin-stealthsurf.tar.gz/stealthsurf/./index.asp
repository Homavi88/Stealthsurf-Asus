<!DOCTYPE html>
<html lang="en">
  <head>
    <!--page:stealthsurf-->
    <meta http-equiv="X-UA-Compatible" content="IE=Edge" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Expires" content="-1" />
    <link rel="shortcut icon" href="images/favicon.png" />
    <link rel="icon" href="images/favicon.png" />
    <title>StealthSurf</title>
    <link rel="stylesheet" type="text/css" href="index_style.css" />
    <link rel="stylesheet" type="text/css" href="form_style.css" />
    <link rel="stylesheet" type="text/css" href="/js/table/table.css" />

    <script language="JavaScript" type="text/javascript" src="/js/jquery.js"></script>
    <script language="JavaScript" type="text/javascript" src="/js/httpApi.js"></script>
    <script language="JavaScript" type="text/javascript" src="/state.js"></script>
    <script language="JavaScript" type="text/javascript" src="/general.js"></script>
    <script language="JavaScript" type="text/javascript" src="/popup.js"></script>
    <script language="JavaScript" type="text/javascript" src="/help.js"></script>
    <script language="JavaScript" type="text/javascript" src="/validator.js"></script>
    <script>
      var xray = {
        router: {
          name: '<% nvram_get("productid"); %>',
          firmware: '<% nvram_get("firmver"); %>',
          language: '<% nvram_get("preferred_lang"); %>',
          ip: '<% nvram_get("lan_ipaddr"); %>',
          territory: '<% nvram_get("territory_code"); %>',
          wan_ip: '<% nvram_get("wan_ipaddr"); %>',
          wan_connected: '<% nvram_get("link_internet"); %>' == '2',
          features: '<% nvram_get("rc_support"); %>',
          is_gnuton: '<% nvram_get("extendno"); %>'.indexOf('gnuton') !== -1
        },
        server: {
          isRunning: parseInt('<% sysinfo("pid.xray"); %>') > 0,
          b4sni_isRunning: parseInt('<% sysinfo("pid.b4sni"); %>') > 0
        }
      };
    </script>
  </head>

  <body>
    <div id="stealthsurf-app"></div>
    <div id="stealthsurf-modals"></div>
    <xmp id="xrayui-data-custom-settings" hidden><% get_custom_settings(); %></xmp>
    <xmp id="xrayui-data-cpu" hidden><% cpu_core_num(); %></xmp>
    <xmp id="xrayui-data-devices-online" hidden><% get_clientlist(); %></xmp>
    <xmp id="xrayui-data-devices" hidden><% get_clientlist_from_json_database(); %></xmp>
    <script>
      (function () {
        function readObject(id) {
          try {
            var value = JSON.parse(document.getElementById(id).textContent);
            if (value && typeof value === 'object' && !Array.isArray(value)) {
              return value;
            }
          } catch (e) {
            console.warn('XRAYUI: ' + id + ' is not valid JSON, using an empty object instead.', e);
          }
          return {};
        }

        var stripAnsi = /\u001b\[[0-9;]*m/g;
        var stripControls = /[\u0000-\u001F]+/g;
        var custom_settings = readObject('xrayui-data-custom-settings');
        Object.keys(custom_settings).forEach(function (key) {
          if (typeof custom_settings[key] === 'string') {
            custom_settings[key] = custom_settings[key].replace(stripAnsi, '').replace(stripControls, '');
          }
        });

        xray.custom_settings = custom_settings;
        xray.router.cpu = parseInt(document.getElementById('xrayui-data-cpu').textContent, 10) || undefined;
        xray.router.devices_online = readObject('xrayui-data-devices-online');
        xray.router.devices = readObject('xrayui-data-devices');
      })();
    </script>
    <script>
      window.addEventListener('load', function () {
        if (xray.router.features) {
          if (xray.router.is_gnuton) {
            return;
          }
          if (xray.router.features.indexOf('rog') !== -1) {
            document.body.classList.add('xrayui-rog');
          } else if (xray.router.features.indexOf('tuf') !== -1) {
            document.body.classList.add('xrayui-tuf');
          }
        }
      });
    </script>
    <script type="module" src="/ext/stealthsurf/app.js"></script>
  </body>
</html>
